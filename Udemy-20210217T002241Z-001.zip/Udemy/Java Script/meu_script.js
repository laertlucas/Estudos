alert('Olá, você já está aprendendo!')
document.getElementById('nome').value = 'Oi'